﻿using Microsoft.AspNetCore.Mvc;
using Niveau.Areas.Admin.Models.Repositories;
using System.Diagnostics;
using Niveau.Areas.Admin.Models;
using Microsoft.AspNetCore.Authorization;

namespace Niveau.Areas.Admin.Controllers
{
    [Area("Admin")]
    public class HomeController : Controller
    {
        private readonly IProductsRepository _productRepository;
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger, IProductsRepository productRepository)
        {
            _logger = logger;
            _productRepository = productRepository;
        }

        [Authorize(Roles = "Admin, Employee")]
        public async Task<IActionResult> Index()
        {
            var product = await _productRepository.GetAllAsync();
            return View(product);
        }
        [Authorize(Roles = "Admin, Employee")]

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}